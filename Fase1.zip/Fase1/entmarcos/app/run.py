from app import create_app

# Crea la aplicación usando la función definida en app/__init__.py
app = create_app()

if __name__ == '__main__':
    # Ejecuta la aplicación en modo de depuración
    app.run(debug=True)