from flask import Blueprint, render_template
from .forms import SNMPForm

main = Blueprint('main', __name__)

@main.route('/', methods=['GET', 'POST'])
def index():
    form = SNMPForm()
    return render_template('index.html', form=form)