from flask_wtf import FlaskForm
from wtforms import StringField, SelectField, SubmitField
from wtforms.validators import DataRequired

class SNMPForm(FlaskForm):
    agent_ip = StringField('IP del Agente', validators=[DataRequired()])
    version = SelectField('Versión SNMP', choices=[('1', 'SNMPv1'), ('2c', 'SNMPv2c')], validators=[DataRequired()])
    community = StringField('Cadena de Comunidad', validators=[DataRequired()])
    oid = StringField('OID', validators=[DataRequired()])
    operation = SelectField('Operación', choices=[
        ('get', 'SNMPGET'),
        ('next', 'SNMPNEXT'),
        ('set', 'SNMPSET'),
        ('bulkwalk', 'SNMPBULKWALK')],
        validators=[DataRequired()]
    )
    submit = SubmitField('Enviar')